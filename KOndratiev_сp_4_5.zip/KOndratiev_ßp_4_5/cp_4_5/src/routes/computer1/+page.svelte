<script>
    import ComputerImg from '../../lib/images/1.png';
    import ComputerImg1 from '../../lib/images/2.png';
    import ComputerImg3 from '../../lib/images/3.png';
</script>

<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    text-align: center;
}

h1 {
    color: rgb(59, 2, 2);
}



.flip-card {
    background-color: transparent;
    width: 200px;
    height: 200px;
    perspective: 1000px;
    align-items: center;
}

.flip-card-inner {
    position: relative;
    width: 100%;
    height: 100%;
    text-align: center;
    transition: transform 0.6s;
    transform-style: preserve-3d;
    align-content: center;
}

.flip-card:hover .flip-card-inner {
    transform: rotateY(180deg);
}

.flip-card-front, .flip-card-back {
    position: absolute;
    width: 100%;
    height: 100%;
    backface-visibility: hidden;
}

.flip-card-front {
    background-color: #bbb;
    color: black;
}

.flip-card-back {
    background-color: #555;
    color: white;
    transform: rotateY(180deg);
}
</style>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Обзор принтеров</title>
    <link rel="stylesheet" href="styles.css">
    <script src="script.js" defer></script>
</head>
<body>
    <h1>Лучшие принтеры для дома</h1>
    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="{ComputerImg}" width="300" alt="Computer 1 Front">
            </div>
            <div class="flip-card-back">
                <h3> Струйное МФУ HP DeskJet 2710 (5AR83B)
                     — лучший струйный принтер до 10 000 рублей</h3>
            </div>
        </div>
    </div>
    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="{ComputerImg1}" width="300" alt="Computer 1 Front">
            </div>
            <div class="flip-card-back">
                <h3> Лазерное МФУ Pantum M6507 — монохромный, 
                    но с Wi-Fi и Bluetooth</h3>
            </div>
        </div>
    </div>
    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="{ComputerImg3}" width="300" alt="Computer 1 Front">
            </div>
            <div class="flip-card-back">
                <h3> Лазерное МФУ Pantum M6507W — быстрая беспроводная печать</h3>
            </div>
        </div>
    </div>
</body>
</html>
