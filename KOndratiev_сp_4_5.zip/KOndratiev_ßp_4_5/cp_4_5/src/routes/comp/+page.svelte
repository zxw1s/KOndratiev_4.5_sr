

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Принтеры</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            padding: 20px;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        
    </style>
</head>
<body>
    <h1>Выберите принтер:</h1>
    <h3>Прежде чем решиться на покупку принтера, определитесь,
         какие задачи вам нужно решать чаще всего.
          Для печати рефератов и отчетов хватит обычного черно-белого принтера, 
          чтобы не переплачивать за дополнительные функции. 
          Например, стоит присмотреться к Pantum P2518 или Pantum P2500W.</h3>
    
</body>
</html>


